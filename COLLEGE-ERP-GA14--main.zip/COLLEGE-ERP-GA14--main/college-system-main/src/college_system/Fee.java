package college_system;

public class Fee {
	private int fid;
	private String name,password;
	public int getFid() {
		return fid;
	}
	public void setFid(int aid) {
		this.fid = fid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

}


